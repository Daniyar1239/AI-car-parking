from fastapi import FastAPI
import psycopg2
from psycopg2.extras import RealDictCursor
import time
from . import models
from sqlalchemy.orm import Session
from .database import engine, SessionLocal, get_db
from .routers import post
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

origins = ["*"]
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

models.Base.metadata.create_all(bind=engine)


while True:
     try: 
          conn = psycopg2.connect(
               host='ec2-13-50-252-13.eu-north-1.compute.amazonaws.com',
               port=5432,
               database='fastapi',
               user='ubuntu',
               password='262266',
               cursor_factory=RealDictCursor
)
          cursor = conn.cursor()
          print('Database connection was succesfull!')
          break

     except Exception as error:
          print('Connecting to database failed!')
          print('Error: ', error)
          time.sleep(2)


app.include_router(post.router)








