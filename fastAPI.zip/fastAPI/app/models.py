from sqlalchemy import Column, Integer, String
from sqlalchemy.sql.expression import text
from .database import Base
from sqlalchemy.sql.sqltypes import TIMESTAMP
from sqlalchemy.types import  Integer, String 





class Spot(Base):
    __tablename__ = "Parking_Spot"

    id = Column(Integer, primary_key=True, nullable=False)
    status_place_1 = Column(String, nullable=False)
    status_place_2 = Column(String, nullable=False)
    status_place_3 = Column(String, nullable=False)
    status_place_4 = Column(String, nullable=False)
    status_place_5 = Column(String, nullable=False)
    status_place_6 = Column(String, nullable=False)
    status_place_7 = Column(String, nullable=False)
    status_place_8 = Column(String, nullable=False)
    status_place_9 = Column(String, nullable=False)
    status_place_10 = Column(String, nullable=False)
    last_changed_at = Column(TIMESTAMP(timezone=True),
                        nullable=False, default=text('now()'))




