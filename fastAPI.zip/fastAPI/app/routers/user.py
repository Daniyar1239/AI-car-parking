from .. import models, schemas, utils
from fastapi import FastAPI, status, Response, Depends, APIRouter
from fastapi.exceptions import HTTPException
from sqlalchemy.orm import Session
from ..database import get_db


router = APIRouter()

@router.post('/users', status_code = status.HTTP_201_CREATED, response_model = schemas.UserOut)
def create_user(user: schemas.UserCreate, db: Session = Depends(get_db)):

     user.password = utils.hash(user.password)

     new_user = models.User(**user.dict())
     db.add(new_user)
     db.commit()
     db.refresh(new_user)

     return new_user