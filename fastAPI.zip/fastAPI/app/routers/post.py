from .. import models, schemas
from fastapi import Response, status, HTTPException, Depends, APIRouter
from fastapi.exceptions import HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from sqlalchemy import desc




router = APIRouter()
### Post Creation (POST)

@router.post('/posts', status_code = status.HTTP_201_CREATED, response_model = schemas.SpotOut)
def create_posts(post: schemas.SpotCreate, db: Session = Depends(get_db)):
     #cursor.execute(""" insert into posts (title, content, published) values (%s, %s, %s) returning * """,
     #              (post.title, post.content, post.published))
     #new_post = cursor.fetchone()
     #conn.commit()
     
     new_post = models.Spot(**post.dict())
     db.add(new_post)
     db.commit()
     db.refresh(new_post)

     return new_post



###Update post by id (PUT)

@router.put('/posts/{id}', response_model = schemas.SpotOut)
def update_post(id: int, updated_post: schemas.SpotCreate, db: Session = Depends(get_db)):

     #cursor.execute(""" update posts set title = %s, content = %s, published = %s where id = %s returning * """, 
     #               (post.title, post.content, post.published, str(id)))
     #updated_post = cursor.fetchone()
     #conn.commit()
     post_query = db.query(models.Spot).filter(models.Spot.id == id)
     post = post_query.first()

     if post == None:
          raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                              detail=f"post with id: {id} doesn't exist")
     
     post_query.update(updated_post.dict(), synchronize_session = False)
     db.commit()

     return post_query.first()




###Get post by ID (GET)

@router.get('/posts/{id}', response_model = schemas.SpotOut)
def get_post(id: int, db: Session = Depends(get_db)):
     
     #cursor.execute(""" select * from posts where id = %s  """, (str(id)) )
     #post = cursor.fetchone()
     post = db.query(models.Spot).filter(models.Spot.id == id).first()

     if not post:
          raise HTTPException(status_code = status.HTTP_404_NOT_FOUND, 
                              detail = f"post with {id} was not found")

     return post


###Get all posts (GET)

@router.get('/posts', response_model = schemas.SpotOut)
def get_posts(db: Session = Depends(get_db)):
     #cursor.execute(""" select * from posts """)
     #posts = cursor.fetchall()
     #print(posts)
     posts = db.query(models.Spot).all()
     return posts



###Delete post by id (DELETE)

@router.delete('/posts/{id}', status_code=status.HTTP_204_NO_CONTENT)
def delete_post(id: int, db: Session = Depends(get_db)):

     #cursor.execute(""" delete from posts where id = %s returning *""", (str(id)))
     #post = cursor.fetchone()
     #conn.commit()

     post = db.query(models.Spot).filter(models.Spot.id == id)

     if post.first() == None:
          raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                              detail=f"post with id: {id} doesn't exist")
     
     post.delete(synchronize_session=False)
     db.commit()
     
     return Response(status_code=status.HTTP_204_NO_CONTENT)




@router.get('/last', response_model = schemas.getLast)
def get_last(db: Session = Depends(get_db)):
     
     #cursor.execute(""" select * from posts where id = %s  """, (str(id)) )
     #post = cursor.fetchone()
     post = db.query(models.Spot).order_by(desc(models.Spot.last_changed_at)).first()

     if not post:
          raise HTTPException(status_code = status.HTTP_404_NOT_FOUND, 
                              detail = f"post with {id} was not found")

     return post