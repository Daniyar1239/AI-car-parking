from pydantic import BaseModel
from datetime import datetime


class SpotBase(BaseModel):

    status_place_1: str
    status_place_2: str
    status_place_3: str
    status_place_4: str
    status_place_5: str
    status_place_6: str
    status_place_7: str
    status_place_8: str
    status_place_9: str
    status_place_10: str

class SpotCreate(SpotBase):
    pass

class SpotOut(SpotBase):

    id: int
    last_changed_at: datetime

    class Config:
        orm_mode =True

class getLast(SpotBase):

    class Config:
        orm_mode =True
    







